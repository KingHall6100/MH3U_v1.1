﻿namespace MH3U
{
    using System;
    using System.Linq;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Timers;
    
    using MH3U.Properties;

    public partial class MainWindow
    {
        private TcpConn tcpConn;

        private Gecko gecko;

        private bool connected;

        private Window1 Win1;

        //public static System.Timers.Timer aTimer;
        public static System.Windows.Threading.DispatcherTimer aTimer;

        private const double CycleInterval = 10000;

        private Int32 RCounter = 0;

        public MainWindow()
        {
            InitializeComponent();

            Win1 = new Window1();
            Win1.Hide();

            IpAddress.Text = Settings.Default.IpAddress;

            //populate combobox with page,row, and col numbers
            int count = 10;
            for (int i = 1; i <= count; i++)
            {
                WPage1.Items.Add(i);
                WRow1.Items.Add(i);
                WCol1.Items.Add(i);

                WPage21.Items.Add(i);
                WRow21.Items.Add(i);
                WCol21.Items.Add(i);

                WPage31.Items.Add(i);
                WRow31.Items.Add(i);
                WCol31.Items.Add(i);

                WPage41.Items.Add(i);
                WRow41.Items.Add(i);
                WCol41.Items.Add(i);

                WPage51.Items.Add(i);
                WRow51.Items.Add(i);
                WCol51.Items.Add(i);

                WPage61.Items.Add(i);
                WRow61.Items.Add(i);
                WCol61.Items.Add(i);
            }

            WPage1.SelectedIndex = 0;
            WRow1.SelectedIndex = 0;
            WCol1.SelectedIndex = 0;

            WPage21.SelectedIndex = 0;
            WRow21.SelectedIndex = 0;
            WCol21.SelectedIndex = 0;

            WPage31.SelectedIndex = 0;
            WRow31.SelectedIndex = 0;
            WCol31.SelectedIndex = 0;

            WPage41.SelectedIndex = 0;
            WRow41.SelectedIndex = 0;
            WCol41.SelectedIndex = 0;

            WPage51.SelectedIndex = 0;
            WRow51.SelectedIndex = 0;
            WCol51.SelectedIndex = 0;

            WPage61.SelectedIndex = 0;
            WRow61.SelectedIndex = 0;
            WCol61.SelectedIndex = 0;

                        // Create a timer with a five second interval.
            aTimer = new System.Windows.Threading.DispatcherTimer();
            aTimer.Tick += new EventHandler(OnTimedEvent);
            aTimer.Interval = TimeSpan.FromSeconds(5);
            aTimer.Stop();

            //This is for debug only
            //ToggleControls("Replicator");

        }

        public void SetTimer(string OffOn)
        {

            var Covert2Sec = (Convert.ToInt16(UpdateInterval.Text));

            //set new time interval
            //aTimer.Interval = Covert2Sec;
            aTimer.Interval = TimeSpan.FromSeconds(Covert2Sec);

            if (OffOn == "OFF")
            {
                aTimer.Stop();
                //aTimer.Enabled = false;
            }
            else if (OffOn == "ON")
            {
                aTimer.Start();
                //aTimer.Enabled = true;
            }
        }

        public void OnTimedEvent(Object source, EventArgs e)
        {
            var playerpointer = gecko.GetUInt(0x2F41FAFC);

            if (playerpointer == 0x0 || playerpointer < 0x30000000)
            {
                //Player is probably no longer on a quest
                //shut off replicator
                Replicator.Content = "Run";
                SetTimer("OFF");
                Capture.IsEnabled = true;
                Write.IsEnabled = true;
            }
            else if (playerpointer > 0x30000000)
            {
                //Player is still on a quest
                //write data
                bool result = ReplicateData();

                if (result == false)
                {
                    //something has gone wrong, must shut off replicator
                    Replicator.Content = "Run";
                    SetTimer("OFF");
                    Capture.IsEnabled = true;
                    Write.IsEnabled = true;
                }
            }
            else
            {
                //Something has gone wrong, shut off replicator
                Replicator.Content = "Run";
                SetTimer("OFF");
                Capture.IsEnabled = true;
                Write.IsEnabled = true;

            }

        }

        private bool ReplicateData()
        {
            uint EnableValue = 0x00007F7F;
            uint DisableValue = 0x00000000;
            uint MaxValue = 0x7FFF7FFF;
            //Floating point
            uint InfiniteValue = 0x50000000;
           

            var tCHealth1 = CHealth1.Text;
            var tCHealth2 = CHealth2.Text;

            var playerpointer = gecko.GetUInt(0x2F41FAFC);

            //Just initialize the variable here and assume not on quest
            var pouchpointer = Convert.ToUInt32(0x0);
            var gpouchpointer = Convert.ToUInt32(0x0);

            //You must be on a quest to use this WriteData function
            if (playerpointer == 0x0 || playerpointer < 0x30000000)
            {
                //You should never be in here if you're on quest, therefore
                //player either ended the quest or back into village.
                //return a false, so the timer would stop.
                return false;
            }
            else if (playerpointer > 0x30000000)
            {
                //Player is on a quest, no need to ask anything
                //increment Counter
                RCounter = RCounter + 1;
                DisplayRCounter.Text = Convert.ToString(RCounter);
                //---------------------------------------------------------------------------------
                //Get Blade Pouch Position
                pouchpointer = gecko.GetUInt(0x2F41FAFC);
                //Read Blade Pouch Data
                //pouchData = gecko.ReadBytes(pouchpointer, 0x80);

                //Get Gunner Pouch Position
                gpouchpointer = gecko.GetUInt(0x2F41FB00);
                //Read Gunner Pouch Data
                //gpouchData = gecko.ReadBytes(gpouchpointer, 0x20);

                //Get Health, Stamina, Air,etc
                var playeraddress = playerpointer + 0x168;

                var health1 = Convert.ToInt16(CHealth1.Text);
                var health2 = Convert.ToInt16(CHealth2.Text);
                gecko.WriteShort(playeraddress, health1);
                gecko.WriteShort(playeraddress + 0x2, health2);

                //This is the redhealth, therefore it's swap in the textbox
                var u1 = Convert.ToInt16(CU1.Text);
                var u2 = Convert.ToInt16(CU2.Text);
                gecko.WriteShort(playeraddress + 0x4, u1);
                gecko.WriteShort(playeraddress + 0x6, u2);

                var stam1 = Convert.ToSingle(CStamina1.Text);
                var stam2 = Convert.ToSingle(CStamina2.Text);
                gecko.WriteFloat(playeraddress + 0x8, stam1);
                gecko.WriteFloat(playeraddress + 0xC, stam2);

                var count1 = Convert.ToSingle(CCountdown1.Text);
                var count2 = Convert.ToSingle(CCountdown2.Text);
                gecko.WriteFloat(playeraddress + 0x10, count1);
                gecko.WriteFloat(playeraddress + 0x14, count2);

                var air1 = Convert.ToInt16(CAir1.Text);
                var air2 = Convert.ToInt16(CAir2.Text);
                gecko.WriteShort(playeraddress + 0x1C, air1);
                gecko.WriteShort(playeraddress + 0x1E, air2);

                //========================================
                //Write food skill
                var foodaddress = playerpointer + 0x966;

                gecko.WriteBytes(foodaddress, gecko.StringToByteArray(FoodSkill1.Text));
                gecko.WriteBytes(foodaddress + 0x2, gecko.StringToByteArray(FoodSkill2.Text));
                gecko.WriteBytes(foodaddress + 0x4, gecko.StringToByteArray(FoodSkill3.Text));

                //=======================================
                //Increase all attack up buffs
                if (CBAttackUp.IsChecked == true)
                {
                    var AttackUpStr = EnableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x414, gecko.StringToByteArray(AttackUpStr));

                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x418, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x454, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x70C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Increase defense up
                if (CBDefenseUp.IsChecked == true)
                {
                    var DefenseUpStr = Convert.ToSingle(AddDefenseUp.Text);
                    gecko.WriteFloat(playerpointer + 0x428, DefenseUpStr);

                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x42C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x718, gecko.StringToByteArray(InfiniteValueStr));
                }
                
                //=======================================
                //Negate Stun
                if (Win1.CBNegateStun.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x790, gecko.StringToByteArray(InfiniteValueStr));

                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x294, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Poison 
                if (Win1.CBNegatePoison.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x24C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Paralysis
                if (Win1.CBNegateParalysis.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x79C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Negate Tremor/Quake
                if (Win1.CBNegateQuake.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x7A8, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Negate Muddy 
                if (Win1.CBNegateMuddy.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x32C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Snow/Ice 
                if (Win1.CBNegateSnow.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x31C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Soiled/Stench 
                if (Win1.CBNegateSnow.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x408, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Wind
                if (Win1.CBNegateWind.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x730, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x43C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Negate Defense Down 
                if (Win1.CBNegateDefDown.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x33C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Elemental Down 
                if (Win1.CBNegateEleDown.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x348, gecko.StringToByteArray(DisableValueStr));
                    gecko.WriteBytes(playerpointer + 0x358, gecko.StringToByteArray(DisableValueStr));
                    gecko.WriteBytes(playerpointer + 0x368, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Slime/Slime Atk Up ?? 
                if (Win1.CBNegateSlime.IsChecked == true)
                {
                    //var DisableValueStr = DisableValue.ToString("X8");
                    //gecko.WriteBytes(playerpointer + 0x850, gecko.StringToByteArray(DisableValueStr));
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x454, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Negate Fire Blight/Negate All Blight 
                if (Win1.CBNegateFire.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x234, gecko.StringToByteArray(DisableValueStr));
                }

                //======================================================
                //Elemental Atk Up
                if (Win1.CBElementalUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x7B4, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Status Atk Up
                if (Win1.CBStatusUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x814, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Purple Sharpness
                if (Win1.CBPurpleSharp.IsChecked == true)
                {
                    var MaxValueStr = MaxValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x624, gecko.StringToByteArray(MaxValueStr));
                }

                //Affinity Up
                if (Win1.CBAffinityUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x808, gecko.StringToByteArray(InfiniteValueStr));
                }

                //HG Earplug
                if (Win1.CBHearing.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x784, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Mega Dash
                if (Win1.CBMegaDash.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x30C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x73C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Move Speed Up / Minds Eye
                if (Win1.CBSpeedUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x700, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Tracker / Show Monster
                if (Win1.CBTracker.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x748, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Hot Cancel / Heat Resist
                if (Win1.CBHotCancel.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x49C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x778, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Cold Cancel / Cold Resist
                if (Win1.CBColdCancel.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x4A8, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x76C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //LS, DB Instant Charge
                if (Win1.CBCharge.IsChecked == true)
                {
                    //LS
                    var EnableValueStr = EnableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x194, gecko.StringToByteArray(EnableValueStr));
                    //DB
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x484, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Dragon Resist
                if (Win1.CBDragonRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x3A4, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3E0, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7F0, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Fire Resist
                if (Win1.CBFireRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x374, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3B0, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7C0, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Water Resist
                if (Win1.CBWaterRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x380, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3BC, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7CC, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Thunder Resist
                if (Win1.CBThunderRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x38C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3C8, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7D8, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Ice Resist
                if (Win1.CBIceRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x398, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3D4, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7E4, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

            }
            else
            {
                //something has gone wrong here. Return false and stop the timer
                return false;
            }

            //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            //==========================================================================================
            //Write Blade Pouch
            //Check to see if we're still on a quest
            playerpointer = gecko.GetUInt(0x2F41FAFC);

            if (playerpointer > 0x30000000)
            {
                if (Convert.ToInt16(CPouch1Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer, gecko.StringToByteArray(CPouch1Id.Text));
                    gecko.WriteShort(pouchpointer + 0x2, Convert.ToInt16(CPouch1Amount.Text));
                }

                if (Convert.ToInt16(CPouch2Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x4, gecko.StringToByteArray(CPouch2Id.Text));
                    gecko.WriteShort(pouchpointer + 0x6, Convert.ToInt16(CPouch2Amount.Text));
                }

                if (Convert.ToInt16(CPouch3Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x8, gecko.StringToByteArray(CPouch3Id.Text));
                    gecko.WriteShort(pouchpointer + 0xA, Convert.ToInt16(CPouch3Amount.Text));
                }

                if (Convert.ToInt16(CPouch4Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0xC, gecko.StringToByteArray(CPouch4Id.Text));
                    gecko.WriteShort(pouchpointer + 0xE, Convert.ToInt16(CPouch4Amount.Text));
                }

                if (Convert.ToInt16(CPouch5Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x10, gecko.StringToByteArray(CPouch5Id.Text));
                    gecko.WriteShort(pouchpointer + 0x12, Convert.ToInt16(CPouch5Amount.Text));
                }

                if (Convert.ToInt16(CPouch6Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x14, gecko.StringToByteArray(CPouch6Id.Text));
                    gecko.WriteShort(pouchpointer + 0x16, Convert.ToInt16(CPouch6Amount.Text));
                }

                if (Convert.ToInt16(CPouch7Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x18, gecko.StringToByteArray(CPouch7Id.Text));
                    gecko.WriteShort(pouchpointer + 0x1A, Convert.ToInt16(CPouch7Amount.Text));
                }

                if (Convert.ToInt16(CPouch8Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x1C, gecko.StringToByteArray(CPouch8Id.Text));
                    gecko.WriteShort(pouchpointer + 0x1E, Convert.ToInt16(CPouch8Amount.Text));
                }

                if (Convert.ToInt16(CPouch9Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x20, gecko.StringToByteArray(CPouch9Id.Text));
                    gecko.WriteShort(pouchpointer + 0x22, Convert.ToInt16(CPouch9Amount.Text));
                }

                if (Convert.ToInt16(CPouch10Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x24, gecko.StringToByteArray(CPouch10Id.Text));
                    gecko.WriteShort(pouchpointer + 0x26, Convert.ToInt16(CPouch10Amount.Text));
                }

                if (Convert.ToInt16(CPouch11Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x28, gecko.StringToByteArray(CPouch11Id.Text));
                    gecko.WriteShort(pouchpointer + 0x2A, Convert.ToInt16(CPouch11Amount.Text));
                }

                if (Convert.ToInt16(CPouch12Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x2C, gecko.StringToByteArray(CPouch12Id.Text));
                    gecko.WriteShort(pouchpointer + 0x2E, Convert.ToInt16(CPouch12Amount.Text));
                }

                if (Convert.ToInt16(CPouch13Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x30, gecko.StringToByteArray(CPouch13Id.Text));
                    gecko.WriteShort(pouchpointer + 0x32, Convert.ToInt16(CPouch13Amount.Text));
                }

                if (Convert.ToInt16(CPouch14Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x34, gecko.StringToByteArray(CPouch14Id.Text));
                    gecko.WriteShort(pouchpointer + 0x36, Convert.ToInt16(CPouch14Amount.Text));
                }

                if (Convert.ToInt16(CPouch15Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x38, gecko.StringToByteArray(CPouch15Id.Text));
                    gecko.WriteShort(pouchpointer + 0x3A, Convert.ToInt16(CPouch15Amount.Text));
                }

                if (Convert.ToInt16(CPouch16Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x3C, gecko.StringToByteArray(CPouch16Id.Text));
                    gecko.WriteShort(pouchpointer + 0x3E, Convert.ToInt16(CPouch16Amount.Text));
                }

                if (Convert.ToInt16(CPouch17Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x40, gecko.StringToByteArray(CPouch17Id.Text));
                    gecko.WriteShort(pouchpointer + 0x42, Convert.ToInt16(CPouch17Amount.Text));
                }

                if (Convert.ToInt16(CPouch18Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x44, gecko.StringToByteArray(CPouch18Id.Text));
                    gecko.WriteShort(pouchpointer + 0x46, Convert.ToInt16(CPouch18Amount.Text));
                }

                if (Convert.ToInt16(CPouch19Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x48, gecko.StringToByteArray(CPouch19Id.Text));
                    gecko.WriteShort(pouchpointer + 0x4A, Convert.ToInt16(CPouch19Amount.Text));
                }

                if (Convert.ToInt16(CPouch20Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x4C, gecko.StringToByteArray(CPouch20Id.Text));
                    gecko.WriteShort(pouchpointer + 0x4E, Convert.ToInt16(CPouch20Amount.Text));
                }

                if (Convert.ToInt16(CPouch21Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x50, gecko.StringToByteArray(CPouch21Id.Text));
                    gecko.WriteShort(pouchpointer + 0x52, Convert.ToInt16(CPouch21Amount.Text));
                }

                if (Convert.ToInt16(CPouch22Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x54, gecko.StringToByteArray(CPouch22Id.Text));
                    gecko.WriteShort(pouchpointer + 0x56, Convert.ToInt16(CPouch22Amount.Text));
                }

                if (Convert.ToInt16(CPouch23Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x58, gecko.StringToByteArray(CPouch23Id.Text));
                    gecko.WriteShort(pouchpointer + 0x5A, Convert.ToInt16(CPouch23Amount.Text));
                }

                if (Convert.ToInt16(CPouch24Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x5C, gecko.StringToByteArray(CPouch24Id.Text));
                    gecko.WriteShort(pouchpointer + 0x5E, Convert.ToInt16(CPouch24Amount.Text));
                }
            }

            //==========================================================================================
            //Get Gunner Pouch
            //Check to see if we're still on a quest
            playerpointer = gecko.GetUInt(0x2F41FAFC);

            if (playerpointer > 0x30000000)
            {
                //check to see if player is a gunner
                if (gpouchpointer > 0x30000000)
                {
                    if (Convert.ToInt16(CGPouch1Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer, gecko.StringToByteArray(CGPouch1Id.Text));
                        gecko.WriteShort(gpouchpointer + 0x2, Convert.ToInt16(CGPouch1Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch2Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0x4, gecko.StringToByteArray(CGPouch2Id.Text));
                        gecko.WriteShort(gpouchpointer + 0x6, Convert.ToInt16(CGPouch2Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch3Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0x8, gecko.StringToByteArray(CGPouch3Id.Text));
                        gecko.WriteShort(gpouchpointer + 0xA, Convert.ToInt16(CGPouch3Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch4Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0xC, gecko.StringToByteArray(CGPouch4Id.Text));
                        gecko.WriteShort(gpouchpointer + 0xE, Convert.ToInt16(CGPouch4Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch5Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0x10, gecko.StringToByteArray(CGPouch5Id.Text));
                        gecko.WriteShort(gpouchpointer + 0x12, Convert.ToInt16(CGPouch5Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch6Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0x14, gecko.StringToByteArray(CGPouch6Id.Text));
                        gecko.WriteShort(gpouchpointer + 0x16, Convert.ToInt16(CGPouch6Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch7Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0x18, gecko.StringToByteArray(CGPouch7Id.Text));
                        gecko.WriteShort(gpouchpointer + 0x1A, Convert.ToInt16(CGPouch7Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch8Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0x1C, gecko.StringToByteArray(CGPouch8Id.Text));
                        gecko.WriteShort(gpouchpointer + 0x1E, Convert.ToInt16(CGPouch8Amount.Text));
                    }
                }
            }

            return true;

        }

        private void ConnectClick(object sender, RoutedEventArgs e)
        {
            try
            {
                tcpConn = new TcpConn(IpAddress.Text, 7331);
                connected = tcpConn.Connect();

                if (!connected)
                {
                    LogError(new Exception("Failed to connect"));
                    return;
                }

                // init gecko
                gecko = new Gecko(tcpConn, this);

                if (connected)
                {
                    var status = gecko.GetServerStatus();
                    if (status == 0)
                    {
                        return;
                    }

                    // Saved settings stuff
                    Settings.Default.IpAddress = IpAddress.Text;
                    Settings.Default.Save();

                    //Controller.SelectedValue = Settings.Default.Controller;

                    ToggleControls("Connected");
                    ToggleControls("Replicator");
                }
            }
            catch (System.Net.Sockets.SocketException)
            {
                connected = false;

                MessageBox.Show("Wrong IP");
            }
            catch (Exception ex)
            {
                LogError(ex);
            }
        }

        private void DisconnectClick(object sender, RoutedEventArgs e)
        {
            try
            {
                tcpConn.Close();

                ToggleControls("Disconnected");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        public void LogError(Exception ex, string more = null)
        {
            var paragraph = new Paragraph
            {
                FontSize = 14,
                Margin = new Thickness(0),
                Padding = new Thickness(0),
                LineHeight = 14
            };

            if (more != null)
            {
                paragraph.Inlines.Add(more + Environment.NewLine);
            }

            paragraph.Inlines.Add(ex.Message);
            paragraph.Inlines.Add(ex.StackTrace);

            ErrorLog.Document.Blocks.Add(paragraph);

            ErrorLog.Document.Blocks.Add(new Paragraph());

            TabControl.IsEnabled = true;

            MessageBox.Show("Error caught. Check Error Tab");
        }

        private void TabControlSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void ToggleControls(string state)
        {
            if (state == "Connected")
            {
                Connect.IsEnabled = false;
                Connect.Visibility = Visibility.Hidden;

                Disconnect.IsEnabled = true;
                Disconnect.Visibility = Visibility.Visible;

                IpAddress.IsEnabled = false;
            }

            if (state == "Disconnected")
            {
                Connect.IsEnabled = true;
                Connect.Visibility = Visibility.Visible;
                Disconnect.IsEnabled = false;
                Disconnect.Visibility = Visibility.Hidden;
                IpAddress.IsEnabled = true;
            }

            if (state == "Replicator")
            {
                //Load.IsEnabled = false;
                //Load.Visibility = Visibility.Hidden;
                //Save.IsEnabled = true;
                //Refresh.IsEnabled = true;
                Replicator.IsEnabled = true;
                Capture.IsEnabled = true;
                Write.IsEnabled = true;
                WeaponRead1.IsEnabled = true;
                WeaponRead2.IsEnabled = true;
                WeaponRead3.IsEnabled = true;
                WeaponRead4.IsEnabled = true;
                WeaponRead5.IsEnabled = true;
                WeaponWrite.IsEnabled = true;
                TabControl.IsEnabled = true;
            }

        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            var regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void ReplicateClick(object sender, RoutedEventArgs e)
        {
            string ButtonState = Convert.ToString(Replicator.Content);

            if (ButtonState == "Stop")
            {
                Replicator.Content = "Run";
                SetTimer("OFF");
                Capture.IsEnabled = true;
                Write.IsEnabled = true;
                return;
            }

            var playerpointer = gecko.GetUInt(0x2F41FAFC);

            if (playerpointer == 0x0 || playerpointer < 0x30000000)
            {
                //Player is probably not on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.Yes)
                {
                    MessageBox.Show("Error: Player data not found! You need to press \"-\" button on the gamepad ones to show player menu. Then try again.", playerpointer.ToString("X4"));
                    Replicator.Content = "Run";
                    SetTimer("OFF");
                    Capture.IsEnabled = true;
                    Write.IsEnabled = true;
                    return;
                }
                else if (dialog == MessageBoxResult.No)
                {
                    MessageBox.Show("Error: You need to be on a quest or outside the village to use this feature. Then try again.", playerpointer.ToString("X4"));
                    Replicator.Content = "Run";
                    SetTimer("OFF");
                    Capture.IsEnabled = true;
                    Write.IsEnabled = true;
                    return;
                }
            }
            else if (playerpointer > 0x30000000)
            {
                //Player is on a quest
                // was going to do a capture first, but realize it gets in the way of game play.
                //CaptureClick(sender, e);

                MessageBoxResult dialog = MessageBox.Show("Start Timer for Replicator?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.No)
                {
                    MessageBox.Show("Replicator will NOT start. Then try again.", playerpointer.ToString("X4"));
                    Replicator.Content = "Run";
                    SetTimer("OFF");
                    Capture.IsEnabled = true;
                    Write.IsEnabled = true;
                    return;
                }

                //Now start the replicator
                Replicator.Content = "Stop";
                SetTimer("ON");
                Capture.IsEnabled = false;
                Write.IsEnabled = false;
                RCounter = 0;
                DisplayRCounter.Text = Convert.ToString(RCounter);
                return;
                    
            }
            else
            {
                MessageBox.Show("Player data invalid. You need to be on a Quest.", playerpointer.ToString("X4"));
                Replicator.Content = "Run";
                SetTimer("OFF");
                Capture.IsEnabled = true;
                Write.IsEnabled = true;
                return;
            }
        }
                
        private void CaptureClick(object sender, RoutedEventArgs e)
        {
            byte[] pouchData = null;
            byte[] gpouchData = null;

            var playerpointer = gecko.GetUInt(0x2F41FAFC);
            //MessageBox.Show(playerpointer.ToString("X4"));

            //Just initialize the variable here and assume not on quest
            var pouchpointer = Convert.ToUInt32(0x0);
            var gpouchpointer = Convert.ToUInt32(0x0);

            if (playerpointer != 0x0 && playerpointer < 0x30000000)
            {
                //Player is probably not on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo,MessageBoxImage.Information);
                if (dialog == MessageBoxResult.Yes)
                {
                    MessageBox.Show("Error: Player data not found! You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                    return;

                }

                //Get Blade Pouch Position
                pouchpointer = gecko.GetUInt(0x2F41FAFC);
                //Read Blade Pouch Data
                pouchData = gecko.ReadBytes(pouchpointer, 0x80);

                //Get Gunner Pouch Position
                gpouchpointer = gecko.GetUInt(0x2F41FB00);
                //Note: Cannot read here in case of player is a blademaster
                //resulting in a zero pointer
                //Read Gunner Pouch Data
                //gpouchData = gecko.ReadBytes(gpouchpointer, 0x20);
            }
            else if (playerpointer > 0x30000000)
            {
                //Player is on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.No)
                {
                    MessageBox.Show("Error has occur! Game thinks you're on a quest. You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                    return;

                }

                //Get Health, Stamina, Air,etc
                var playeraddress = playerpointer + 0x168;
                var playerdata = gecko.ReadBytes(playeraddress, 0x20);

                var health1 = BitConverter.ToInt16(playerdata.Skip(0).Take(2).Reverse().ToArray(), 0);
                var health2 = BitConverter.ToInt16(playerdata.Skip(2).Take(2).Reverse().ToArray(), 0);
                CHealth1.Text = health1.ToString();
                CHealth2.Text = health2.ToString();

                //This is the redhealth, therefore it's swap in the textbox
                var u1 = BitConverter.ToInt16(playerdata.Skip(4).Take(2).Reverse().ToArray(), 0);
                var u2 = BitConverter.ToInt16(playerdata.Skip(6).Take(2).Reverse().ToArray(), 0);
                CU1.Text = u1.ToString();
                CU2.Text = u2.ToString();

                var stam1 = BitConverter.ToSingle(playerdata.Skip(8).Take(4).Reverse().ToArray(), 0);
                var stam2 = BitConverter.ToSingle(playerdata.Skip(12).Take(4).Reverse().ToArray(), 0);
                CStamina1.Text = Math.Round(stam1, 0).ToString();
                CStamina2.Text = Math.Round(stam2, 0).ToString();

                var count1 = BitConverter.ToSingle(playerdata.Skip(16).Take(4).Reverse().ToArray(), 0);
                var count2 = BitConverter.ToSingle(playerdata.Skip(20).Take(4).Reverse().ToArray(), 0);
                CCountdown1.Text = Math.Round(count1, 0).ToString();
                CCountdown2.Text = Math.Round(count2, 0).ToString();

                var air1 = BitConverter.ToInt16(playerdata.Skip(28).Take(2).Reverse().ToArray(), 0);
                var air2 = BitConverter.ToInt16(playerdata.Skip(30).Take(2).Reverse().ToArray(), 0);
                CAir1.Text = air1.ToString();
                CAir2.Text = air2.ToString();

                //Read Food Skill
                var foodaddress = playerpointer + 0x966;
                var fooddata = gecko.ReadBytes(foodaddress, 0x06);

                if (fooddata.Length > 0 && fooddata != null)
                {
                    FoodSkill1.Text = BitConverter.ToString(fooddata.Skip(0).Take(2).ToArray()).Replace("-", "");
                    FoodSkill2.Text = BitConverter.ToString(fooddata.Skip(2).Take(2).ToArray()).Replace("-", "");
                    FoodSkill3.Text = BitConverter.ToString(fooddata.Skip(4).Take(2).ToArray()).Replace("-", "");
                }
                else
                {
                    FoodSkill1.Text = "0000";
                    FoodSkill2.Text = "0000";
                    FoodSkill3.Text = "0000";
                }
                //---------------------------------------------------------------------------------
                //Get Blade Pouch Position
                pouchpointer = gecko.GetUInt(0x2F41FAFC);
                //Read Blade Pouch Data
                pouchData = gecko.ReadBytes(pouchpointer, 0x80);

                //Get Gunner Pouch Position
                gpouchpointer = gecko.GetUInt(0x2F41FB00);
                //Note: Cannot read here in case of player is a blademaster
                //resulting in a zero pointer
                //Read Gunner Pouch Data
                //gpouchData = gecko.ReadBytes(gpouchpointer, 0x20);
            }
            else
            {
                MessageBox.Show("Player data invalid. You need to press \"-\" button on the gamepad to show player menu. Then try again.",playerpointer.ToString("X4"));
                return;
            }

            //==========================================================================================
            //Get Blade Pouch

            CPouch1Id.Text = BitConverter.ToString(pouchData.Skip(0).Take(2).ToArray()).Replace("-", "");
            CPouch1Amount.Text = BitConverter.ToInt16(pouchData.Skip(2).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch2Id.Text = BitConverter.ToString(pouchData.Skip(4).Take(2).ToArray()).Replace("-", "");
            CPouch2Amount.Text = BitConverter.ToInt16(pouchData.Skip(6).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch3Id.Text = BitConverter.ToString(pouchData.Skip(8).Take(2).ToArray()).Replace("-", "");
            CPouch3Amount.Text = BitConverter.ToInt16(pouchData.Skip(10).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch4Id.Text = BitConverter.ToString(pouchData.Skip(12).Take(2).ToArray()).Replace("-", "");
            CPouch4Amount.Text = BitConverter.ToInt16(pouchData.Skip(14).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch5Id.Text = BitConverter.ToString(pouchData.Skip(16).Take(2).ToArray()).Replace("-", "");
            CPouch5Amount.Text = BitConverter.ToInt16(pouchData.Skip(18).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch6Id.Text = BitConverter.ToString(pouchData.Skip(20).Take(2).ToArray()).Replace("-", "");
            CPouch6Amount.Text = BitConverter.ToInt16(pouchData.Skip(22).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch7Id.Text = BitConverter.ToString(pouchData.Skip(24).Take(2).ToArray()).Replace("-", "");
            CPouch7Amount.Text = BitConverter.ToInt16(pouchData.Skip(26).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch8Id.Text = BitConverter.ToString(pouchData.Skip(28).Take(2).ToArray()).Replace("-", "");
            CPouch8Amount.Text = BitConverter.ToInt16(pouchData.Skip(30).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch9Id.Text = BitConverter.ToString(pouchData.Skip(32).Take(2).ToArray()).Replace("-", "");
            CPouch9Amount.Text = BitConverter.ToInt16(pouchData.Skip(34).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch10Id.Text = BitConverter.ToString(pouchData.Skip(36).Take(2).ToArray()).Replace("-", "");
            CPouch10Amount.Text = BitConverter.ToInt16(pouchData.Skip(38).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch11Id.Text = BitConverter.ToString(pouchData.Skip(40).Take(2).ToArray()).Replace("-", "");
            CPouch11Amount.Text = BitConverter.ToInt16(pouchData.Skip(42).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch12Id.Text = BitConverter.ToString(pouchData.Skip(44).Take(2).ToArray()).Replace("-", "");
            CPouch12Amount.Text = BitConverter.ToInt16(pouchData.Skip(46).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch13Id.Text = BitConverter.ToString(pouchData.Skip(48).Take(2).ToArray()).Replace("-", "");
            CPouch13Amount.Text = BitConverter.ToInt16(pouchData.Skip(50).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch14Id.Text = BitConverter.ToString(pouchData.Skip(52).Take(2).ToArray()).Replace("-", "");
            CPouch14Amount.Text = BitConverter.ToInt16(pouchData.Skip(54).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch15Id.Text = BitConverter.ToString(pouchData.Skip(56).Take(2).ToArray()).Replace("-", "");
            CPouch15Amount.Text = BitConverter.ToInt16(pouchData.Skip(58).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch16Id.Text = BitConverter.ToString(pouchData.Skip(60).Take(2).ToArray()).Replace("-", "");
            CPouch16Amount.Text = BitConverter.ToInt16(pouchData.Skip(62).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch17Id.Text = BitConverter.ToString(pouchData.Skip(64).Take(2).ToArray()).Replace("-", "");
            CPouch17Amount.Text = BitConverter.ToInt16(pouchData.Skip(66).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch18Id.Text = BitConverter.ToString(pouchData.Skip(68).Take(2).ToArray()).Replace("-", "");
            CPouch18Amount.Text = BitConverter.ToInt16(pouchData.Skip(70).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch19Id.Text = BitConverter.ToString(pouchData.Skip(72).Take(2).ToArray()).Replace("-", "");
            CPouch19Amount.Text = BitConverter.ToInt16(pouchData.Skip(74).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch20Id.Text = BitConverter.ToString(pouchData.Skip(76).Take(2).ToArray()).Replace("-", "");
            CPouch20Amount.Text = BitConverter.ToInt16(pouchData.Skip(78).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch21Id.Text = BitConverter.ToString(pouchData.Skip(80).Take(2).ToArray()).Replace("-", "");
            CPouch21Amount.Text = BitConverter.ToInt16(pouchData.Skip(82).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch22Id.Text = BitConverter.ToString(pouchData.Skip(84).Take(2).ToArray()).Replace("-", "");
            CPouch22Amount.Text = BitConverter.ToInt16(pouchData.Skip(86).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch23Id.Text = BitConverter.ToString(pouchData.Skip(88).Take(2).ToArray()).Replace("-", "");
            CPouch23Amount.Text = BitConverter.ToInt16(pouchData.Skip(90).Take(2).Reverse().ToArray(), 0).ToString();

            CPouch24Id.Text = BitConverter.ToString(pouchData.Skip(92).Take(2).ToArray()).Replace("-", "");
            CPouch24Amount.Text = BitConverter.ToInt16(pouchData.Skip(94).Take(2).Reverse().ToArray(), 0).ToString();

            //==========================================================================================
            //Get Gunner Pouch
            //check to see if player is a gunner
            if (gpouchpointer > 0x30000000)
            {
                //Read Gunner Pouch Data
                gpouchData = gecko.ReadBytes(gpouchpointer, 0x20);

                CGPouch1Id.Text = BitConverter.ToString(gpouchData.Skip(0).Take(2).ToArray()).Replace("-", "");
                CGPouch1Amount.Text = BitConverter.ToInt16(gpouchData.Skip(2).Take(2).Reverse().ToArray(), 0).ToString();

                CGPouch2Id.Text = BitConverter.ToString(gpouchData.Skip(4).Take(2).ToArray()).Replace("-", "");
                CGPouch2Amount.Text = BitConverter.ToInt16(gpouchData.Skip(6).Take(2).Reverse().ToArray(), 0).ToString();

                CGPouch3Id.Text = BitConverter.ToString(gpouchData.Skip(8).Take(2).ToArray()).Replace("-", "");
                CGPouch3Amount.Text = BitConverter.ToInt16(gpouchData.Skip(10).Take(2).Reverse().ToArray(), 0).ToString();

                CGPouch4Id.Text = BitConverter.ToString(gpouchData.Skip(12).Take(2).ToArray()).Replace("-", "");
                CGPouch4Amount.Text = BitConverter.ToInt16(gpouchData.Skip(14).Take(2).Reverse().ToArray(), 0).ToString();

                CGPouch5Id.Text = BitConverter.ToString(gpouchData.Skip(16).Take(2).ToArray()).Replace("-", "");
                CGPouch5Amount.Text = BitConverter.ToInt16(gpouchData.Skip(18).Take(2).Reverse().ToArray(), 0).ToString();

                CGPouch6Id.Text = BitConverter.ToString(gpouchData.Skip(20).Take(2).ToArray()).Replace("-", "");
                CGPouch6Amount.Text = BitConverter.ToInt16(gpouchData.Skip(22).Take(2).Reverse().ToArray(), 0).ToString();

                CGPouch7Id.Text = BitConverter.ToString(gpouchData.Skip(24).Take(2).ToArray()).Replace("-", "");
                CGPouch7Amount.Text = BitConverter.ToInt16(gpouchData.Skip(26).Take(2).Reverse().ToArray(), 0).ToString();

                CGPouch8Id.Text = BitConverter.ToString(gpouchData.Skip(28).Take(2).ToArray()).Replace("-", "");
                CGPouch8Amount.Text = BitConverter.ToInt16(gpouchData.Skip(30).Take(2).Reverse().ToArray(), 0).ToString();
            }
            return;
        }

        private void WriteClick(object sender, RoutedEventArgs e)
        {
            uint EnableValue = 0x00007F7F;
            uint DisableValue = 0x00000000;
            uint MaxValue = 0x7FFF7FFF;
            //Floating point
            uint InfiniteValue = 0x50000000;

            var playerpointer = gecko.GetUInt(0x2F41FAFC);

            //Just initialize the variable here and assume not on quest
            var pouchpointer = Convert.ToUInt32(0x0);
            var gpouchpointer = Convert.ToUInt32(0x0);

            //MessageBox.Show(playerpointer.ToString("X4"));

            if (playerpointer != 0x0 && playerpointer < 0x30000000)
            {
                //Player is probably not on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.Yes)
                {
                    MessageBox.Show("Error: Player data not found! You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                    return;

                }

                //Get Blade Pouch Position
                pouchpointer = gecko.GetUInt(0x2F41FAFC);
                //Read Blade Pouch Data
                //pouchData = gecko.ReadBytes(pouchpointer, 0x80);

                //Get Gunner Pouch Position
                gpouchpointer = gecko.GetUInt(0x2F41FB00);
                //Read Gunner Pouch Data
                //gpouchData = gecko.ReadBytes(gpouchpointer, 0x20);
            }
            else if (playerpointer > 0x30000000)
            {
                //Player is on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.No)
                {
                    MessageBox.Show("Error has occur! Game thinks you're on a quest. You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                    return;

                }

                //---------------------------------------------------------------------------------
                //Get Blade Pouch Position
                pouchpointer = gecko.GetUInt(0x2F41FAFC);
                //Read Blade Pouch Data
                //pouchData = gecko.ReadBytes(pouchpointer, 0x80);

                //Get Gunner Pouch Position
                gpouchpointer = gecko.GetUInt(0x2F41FB00);
                //Read Gunner Pouch Data
                //gpouchData = gecko.ReadBytes(gpouchpointer, 0x20);

                //Get Health, Stamina, Air,etc
                var playeraddress = playerpointer + 0x168;

                var health1 = Convert.ToInt16(CHealth1.Text);
                var health2 = Convert.ToInt16(CHealth2.Text);
                gecko.WriteShort(playeraddress, health1);
                gecko.WriteShort(playeraddress + 0x2, health2);

                //This is the redhealth, therefore it's swap in the textbox
                var u1 = Convert.ToInt16(CU1.Text);
                var u2 = Convert.ToInt16(CU2.Text);
                gecko.WriteShort(playeraddress + 0x4, u1);
                gecko.WriteShort(playeraddress + 0x6, u2);

                var stam1 = Convert.ToSingle(CStamina1.Text);
                var stam2 = Convert.ToSingle(CStamina2.Text);
                gecko.WriteFloat(playeraddress + 0x8, stam1);
                gecko.WriteFloat(playeraddress + 0xC, stam2);

                var count1 = Convert.ToSingle(CCountdown1.Text);
                var count2 = Convert.ToSingle(CCountdown2.Text);
                gecko.WriteFloat(playeraddress + 0x10, count1);
                gecko.WriteFloat(playeraddress + 0x14, count2);

                var air1 = Convert.ToInt16(CAir1.Text);
                var air2 = Convert.ToInt16(CAir2.Text);
                gecko.WriteShort(playeraddress + 0x1C, air1);
                gecko.WriteShort(playeraddress + 0x1E, air2);

                //========================================
                //Write food skill
                var foodaddress = playerpointer + 0x966;

                gecko.WriteBytes(foodaddress, gecko.StringToByteArray(FoodSkill1.Text));
                gecko.WriteBytes(foodaddress + 0x2, gecko.StringToByteArray(FoodSkill2.Text));
                gecko.WriteBytes(foodaddress + 0x4, gecko.StringToByteArray(FoodSkill3.Text));

                //=======================================
                //Increase all attack up buffs
                if (CBAttackUp.IsChecked == true)
                {
                    var AttackUpStr = EnableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x414, gecko.StringToByteArray(AttackUpStr));

                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x418, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x454, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x70C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Increase defense up
                if (CBDefenseUp.IsChecked == true)
                {
                    var DefenseUpStr = Convert.ToSingle(AddDefenseUp.Text);
                    gecko.WriteFloat(playerpointer + 0x428, DefenseUpStr);

                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x42C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x718, gecko.StringToByteArray(InfiniteValueStr));
                }

                //=======================================
                //Negate Stun
                if (Win1.CBNegateStun.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x790, gecko.StringToByteArray(InfiniteValueStr));

                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x294, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Poison 
                if (Win1.CBNegatePoison.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x24C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Paralysis
                if (Win1.CBNegateParalysis.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x79C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Negate Tremor/Quake
                if (Win1.CBNegateQuake.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x7A8, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Negate Muddy 
                if (Win1.CBNegateMuddy.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x32C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Snow/Ice 
                if (Win1.CBNegateSnow.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x31C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Soiled/Stench 
                if (Win1.CBNegateSnow.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x408, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Wind
                if (Win1.CBNegateWind.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x730, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x43C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Negate Defense Down 
                if (Win1.CBNegateDefDown.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x33C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Elemental Down 
                if (Win1.CBNegateEleDown.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x348, gecko.StringToByteArray(DisableValueStr));
                    gecko.WriteBytes(playerpointer + 0x358, gecko.StringToByteArray(DisableValueStr));
                    gecko.WriteBytes(playerpointer + 0x368, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Slime  
                if (Win1.CBNegateSlime.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x2AC, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Fire Blight/Negate All Blight 
                if (Win1.CBNegateFire.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x234, gecko.StringToByteArray(DisableValueStr));
                }

                //======================================================
                //Elemental Atk Up
                if (Win1.CBElementalUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x7B4, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Status Atk Up
                if (Win1.CBStatusUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x814, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Purple Sharpness/Increase Sharpness
                if (Win1.CBPurpleSharp.IsChecked == true)
                {
                    var MaxValueStr = MaxValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x624, gecko.StringToByteArray(MaxValueStr));
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x454, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Affinity Up
                if (Win1.CBAffinityUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x808, gecko.StringToByteArray(InfiniteValueStr));
                }

                //HG Earplug
                if (Win1.CBHearing.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x784, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Mega Dash
                if (Win1.CBMegaDash.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x30C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x73C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Move Speed Up / Minds Eye
                if (Win1.CBSpeedUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x700, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Tracker / Show Monster
                if (Win1.CBTracker.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x748, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Hot Cancel / Heat Resist
                if (Win1.CBHotCancel.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x49C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x778, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Cold Cancel / Cold Resist
                if (Win1.CBColdCancel.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x4A8, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x76C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //LS, DB Instant Charge
                if (Win1.CBCharge.IsChecked == true)
                {
                    //LS
                    var EnableValueStr = EnableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x194, gecko.StringToByteArray(EnableValueStr));
                    //DB
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x484, gecko.StringToByteArray(InfiniteValueStr));

                    //Enable Instant charge of bow and else ??? need more testing.
                    gecko.WriteBytes(playerpointer + 0x198, gecko.StringToByteArray(EnableValueStr));
                    gecko.WriteBytes(playerpointer + 0x19C, gecko.StringToByteArray(EnableValueStr));
                    gecko.WriteBytes(playerpointer + 0x1A0, gecko.StringToByteArray(EnableValueStr));
                    gecko.WriteBytes(playerpointer + 0x1A4, gecko.StringToByteArray(EnableValueStr));

                    gecko.WriteBytes(playerpointer + 0x1A8, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Dragon Resist
                if (Win1.CBDragonRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x3A4, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3E0, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7F0, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Fire Resist
                if (Win1.CBFireRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x374, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3B0, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7C0, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Water Resist
                if (Win1.CBWaterRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x380, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3BC, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7CC, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Thunder Resist
                if (Win1.CBThunderRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x38C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3C8, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7D8, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Ice Resist
                if (Win1.CBIceRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x398, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3D4, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7E4, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

            }
            else
            {
                MessageBox.Show("Player data invalid. You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                return;
            }

            //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            //==========================================================================================
            //Write Blade Pouch
            
            gecko.WriteBytes(pouchpointer, gecko.StringToByteArray(CPouch1Id.Text));
            gecko.WriteShort(pouchpointer + 0x2, Convert.ToInt16(CPouch1Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x4, gecko.StringToByteArray(CPouch2Id.Text));
            gecko.WriteShort(pouchpointer + 0x6, Convert.ToInt16(CPouch2Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x8, gecko.StringToByteArray(CPouch3Id.Text));
            gecko.WriteShort(pouchpointer + 0xA, Convert.ToInt16(CPouch3Amount.Text));

            gecko.WriteBytes(pouchpointer + 0xC, gecko.StringToByteArray(CPouch4Id.Text));
            gecko.WriteShort(pouchpointer + 0xE, Convert.ToInt16(CPouch4Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x10, gecko.StringToByteArray(CPouch5Id.Text));
            gecko.WriteShort(pouchpointer + 0x12, Convert.ToInt16(CPouch5Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x14, gecko.StringToByteArray(CPouch6Id.Text));
            gecko.WriteShort(pouchpointer + 0x16, Convert.ToInt16(CPouch6Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x18, gecko.StringToByteArray(CPouch7Id.Text));
            gecko.WriteShort(pouchpointer + 0x1A, Convert.ToInt16(CPouch7Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x1C, gecko.StringToByteArray(CPouch8Id.Text));
            gecko.WriteShort(pouchpointer + 0x1E, Convert.ToInt16(CPouch8Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x20, gecko.StringToByteArray(CPouch9Id.Text));
            gecko.WriteShort(pouchpointer + 0x22, Convert.ToInt16(CPouch9Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x24, gecko.StringToByteArray(CPouch10Id.Text));
            gecko.WriteShort(pouchpointer + 0x26, Convert.ToInt16(CPouch10Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x28, gecko.StringToByteArray(CPouch11Id.Text));
            gecko.WriteShort(pouchpointer + 0x2A, Convert.ToInt16(CPouch11Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x2C, gecko.StringToByteArray(CPouch12Id.Text));
            gecko.WriteShort(pouchpointer + 0x2E, Convert.ToInt16(CPouch12Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x30, gecko.StringToByteArray(CPouch13Id.Text));
            gecko.WriteShort(pouchpointer + 0x32, Convert.ToInt16(CPouch13Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x34, gecko.StringToByteArray(CPouch14Id.Text));
            gecko.WriteShort(pouchpointer + 0x36, Convert.ToInt16(CPouch14Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x38, gecko.StringToByteArray(CPouch15Id.Text));
            gecko.WriteShort(pouchpointer + 0x3A, Convert.ToInt16(CPouch15Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x3C, gecko.StringToByteArray(CPouch16Id.Text));
            gecko.WriteShort(pouchpointer + 0x3E, Convert.ToInt16(CPouch16Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x40, gecko.StringToByteArray(CPouch17Id.Text));
            gecko.WriteShort(pouchpointer + 0x42, Convert.ToInt16(CPouch17Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x44, gecko.StringToByteArray(CPouch18Id.Text));
            gecko.WriteShort(pouchpointer + 0x46, Convert.ToInt16(CPouch18Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x48, gecko.StringToByteArray(CPouch19Id.Text));
            gecko.WriteShort(pouchpointer + 0x4A, Convert.ToInt16(CPouch19Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x4C, gecko.StringToByteArray(CPouch20Id.Text));
            gecko.WriteShort(pouchpointer + 0x4E, Convert.ToInt16(CPouch20Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x50, gecko.StringToByteArray(CPouch21Id.Text));
            gecko.WriteShort(pouchpointer + 0x52, Convert.ToInt16(CPouch21Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x54, gecko.StringToByteArray(CPouch22Id.Text));
            gecko.WriteShort(pouchpointer + 0x56, Convert.ToInt16(CPouch22Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x58, gecko.StringToByteArray(CPouch23Id.Text));
            gecko.WriteShort(pouchpointer + 0x5A, Convert.ToInt16(CPouch23Amount.Text));

            gecko.WriteBytes(pouchpointer + 0x5C, gecko.StringToByteArray(CPouch24Id.Text));
            gecko.WriteShort(pouchpointer + 0x5E, Convert.ToInt16(CPouch24Amount.Text));

            //==========================================================================================
            //Get Gunner Pouch
            //check to see if player is a gunner

            if (gpouchpointer > 0x30000000)
            {
                gecko.WriteBytes(gpouchpointer, gecko.StringToByteArray(CGPouch1Id.Text));
                gecko.WriteShort(gpouchpointer + 0x2, Convert.ToInt16(CGPouch1Amount.Text));

                gecko.WriteBytes(gpouchpointer + 0x4, gecko.StringToByteArray(CGPouch2Id.Text));
                gecko.WriteShort(gpouchpointer + 0x6, Convert.ToInt16(CGPouch2Amount.Text));

                gecko.WriteBytes(gpouchpointer + 0x8, gecko.StringToByteArray(CGPouch3Id.Text));
                gecko.WriteShort(gpouchpointer + 0xA, Convert.ToInt16(CGPouch3Amount.Text));

                gecko.WriteBytes(gpouchpointer + 0xC, gecko.StringToByteArray(CGPouch4Id.Text));
                gecko.WriteShort(gpouchpointer + 0xE, Convert.ToInt16(CGPouch4Amount.Text));

                gecko.WriteBytes(gpouchpointer + 0x10, gecko.StringToByteArray(CGPouch5Id.Text));
                gecko.WriteShort(gpouchpointer + 0x12, Convert.ToInt16(CGPouch5Amount.Text));

                gecko.WriteBytes(gpouchpointer + 0x14, gecko.StringToByteArray(CGPouch6Id.Text));
                gecko.WriteShort(gpouchpointer + 0x16, Convert.ToInt16(CGPouch6Amount.Text));

                gecko.WriteBytes(gpouchpointer + 0x18, gecko.StringToByteArray(CGPouch7Id.Text));
                gecko.WriteShort(gpouchpointer + 0x1A, Convert.ToInt16(CGPouch7Amount.Text));

                gecko.WriteBytes(gpouchpointer + 0x1C, gecko.StringToByteArray(CGPouch8Id.Text));
                gecko.WriteShort(gpouchpointer + 0x1E, Convert.ToInt16(CGPouch8Amount.Text));
            }

            return;

        }

        private void Read1Click(object sender, RoutedEventArgs e)
        {
            Int32 WeaponAddress = 0x2F4495E0;
            int PageNum = 0x640;
            int RowNum = 0xA0;
            int ColNum = 0x10;

            var SelPage = (Convert.ToInt32(WPage1.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(WRow1.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(WCol1.SelectedItem)) - 1;

            //Now set the write field to be the same
            WPage61.SelectedItem = WPage1.SelectedItem;
            WRow61.SelectedItem = WRow1.SelectedItem;
            WCol61.SelectedItem = WCol1.SelectedItem;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

            Address1.Text = WeaponPointer.ToString("X8");

            //set the write address to be the same
            Address61.Text = WeaponPointer.ToString("X8");

            var weapondata = gecko.ReadBytes(WeaponPointer, 0x10);

            if (weapondata.Length > 0 && weapondata != null)
            {
                var tdata1 = BitConverter.ToInt32(weapondata.Skip(0).Take(4).Reverse().ToArray(), 0);
                var tdata2 = BitConverter.ToInt32(weapondata.Skip(4).Take(4).Reverse().ToArray(), 0);
                var tdata3 = BitConverter.ToInt32(weapondata.Skip(8).Take(4).Reverse().ToArray(), 0);
                var tdata4 = BitConverter.ToInt32(weapondata.Skip(12).Take(4).Reverse().ToArray(), 0);

                Data1.Text = tdata1.ToString("X8");
                Data2.Text = tdata2.ToString("X8");
                Data3.Text = tdata3.ToString("X8");
                Data4.Text = tdata4.ToString("X8");

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = tdata1.ToString("X8");
                Data62.Text = tdata2.ToString("X8");
                Data63.Text = tdata3.ToString("X8");
                Data64.Text = tdata4.ToString("X8");
            }
            else
            {
                Data1.Text = "00000000";
                Data2.Text = "00000000"; 
                Data3.Text = "00000000"; 
                Data4.Text = "00000000";

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = "00000000";
                Data62.Text = "00000000";
                Data63.Text = "00000000";
                Data64.Text = "00000000";
            }

        }

        private void Read2Click(object sender, RoutedEventArgs e)
        {
            Int32 WeaponAddress = 0x2F4495E0;
            int PageNum = 0x640;
            int RowNum = 0xA0;
            int ColNum = 0x10;

            var SelPage = (Convert.ToInt32(WPage21.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(WRow21.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(WCol21.SelectedItem)) - 1;

            //Now set the write field to be the same
            WPage61.SelectedItem = WPage21.SelectedItem;
            WRow61.SelectedItem = WRow21.SelectedItem;
            WCol61.SelectedItem = WCol21.SelectedItem;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

            Address21.Text = WeaponPointer.ToString("X8");

            //set the write address to be the same
            Address61.Text = WeaponPointer.ToString("X8");

            var weapondata = gecko.ReadBytes(WeaponPointer, 0x10);

            if (weapondata.Length > 0 && weapondata != null)
            {
                var tdata21 = BitConverter.ToInt32(weapondata.Skip(0).Take(4).Reverse().ToArray(), 0);
                var tdata22 = BitConverter.ToInt32(weapondata.Skip(4).Take(4).Reverse().ToArray(), 0);
                var tdata23 = BitConverter.ToInt32(weapondata.Skip(8).Take(4).Reverse().ToArray(), 0);
                var tdata24 = BitConverter.ToInt32(weapondata.Skip(12).Take(4).Reverse().ToArray(), 0);

                Data21.Text = tdata21.ToString("X8");
                Data22.Text = tdata22.ToString("X8");
                Data23.Text = tdata23.ToString("X8");
                Data24.Text = tdata24.ToString("X8");

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = tdata21.ToString("X8");
                Data62.Text = tdata22.ToString("X8");
                Data63.Text = tdata23.ToString("X8");
                Data64.Text = tdata24.ToString("X8");
            }
            else
            {
                Data21.Text = "00000000";
                Data22.Text = "00000000";
                Data23.Text = "00000000";
                Data24.Text = "00000000";

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = "00000000";
                Data62.Text = "00000000";
                Data63.Text = "00000000";
                Data64.Text = "00000000";
            }

        }

        private void Read3Click(object sender, RoutedEventArgs e)
        {
            Int32 WeaponAddress = 0x2F4495E0;
            int PageNum = 0x640;
            int RowNum = 0xA0;
            int ColNum = 0x10;

            var SelPage = (Convert.ToInt32(WPage31.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(WRow31.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(WCol31.SelectedItem)) - 1;

            //Now set the write field to be the same
            WPage61.SelectedItem = WPage31.SelectedItem;
            WRow61.SelectedItem = WRow31.SelectedItem;
            WCol61.SelectedItem = WCol31.SelectedItem;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

            Address31.Text = WeaponPointer.ToString("X8");

            //set the write address to be the same
            Address61.Text = WeaponPointer.ToString("X8");

            var weapondata = gecko.ReadBytes(WeaponPointer, 0x10);

            if (weapondata.Length > 0 && weapondata != null)
            {
                var tdata31 = BitConverter.ToInt32(weapondata.Skip(0).Take(4).Reverse().ToArray(), 0);
                var tdata32 = BitConverter.ToInt32(weapondata.Skip(4).Take(4).Reverse().ToArray(), 0);
                var tdata33 = BitConverter.ToInt32(weapondata.Skip(8).Take(4).Reverse().ToArray(), 0);
                var tdata34 = BitConverter.ToInt32(weapondata.Skip(12).Take(4).Reverse().ToArray(), 0);

                Data31.Text = tdata31.ToString("X8");
                Data32.Text = tdata32.ToString("X8");
                Data33.Text = tdata33.ToString("X8");
                Data34.Text = tdata34.ToString("X8");

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = tdata31.ToString("X8");
                Data62.Text = tdata32.ToString("X8");
                Data63.Text = tdata33.ToString("X8");
                Data64.Text = tdata34.ToString("X8");
            }
            else
            {
                Data31.Text = "00000000";
                Data32.Text = "00000000";
                Data33.Text = "00000000";
                Data34.Text = "00000000";

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = "00000000";
                Data62.Text = "00000000";
                Data63.Text = "00000000";
                Data64.Text = "00000000";
            }
        }

        private void Read4Click(object sender, RoutedEventArgs e)
        {
            Int32 WeaponAddress = 0x2F4495E0;
            int PageNum = 0x640;
            int RowNum = 0xA0;
            int ColNum = 0x10;

            var SelPage = (Convert.ToInt32(WPage41.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(WRow41.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(WCol41.SelectedItem)) - 1;

            //Now set the write field to be the same
            WPage61.SelectedItem = WPage41.SelectedItem;
            WRow61.SelectedItem = WRow41.SelectedItem;
            WCol61.SelectedItem = WCol41.SelectedItem;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

            Address41.Text = WeaponPointer.ToString("X8");

            //set the write address to be the same
            Address61.Text = WeaponPointer.ToString("X8");

            var weapondata = gecko.ReadBytes(WeaponPointer, 0x10);

            if (weapondata.Length > 0 && weapondata != null)
            {
                var tdata41 = BitConverter.ToInt32(weapondata.Skip(0).Take(4).Reverse().ToArray(), 0);
                var tdata42 = BitConverter.ToInt32(weapondata.Skip(4).Take(4).Reverse().ToArray(), 0);
                var tdata43 = BitConverter.ToInt32(weapondata.Skip(8).Take(4).Reverse().ToArray(), 0);
                var tdata44 = BitConverter.ToInt32(weapondata.Skip(12).Take(4).Reverse().ToArray(), 0);

                Data41.Text = tdata41.ToString("X8");
                Data42.Text = tdata42.ToString("X8");
                Data43.Text = tdata43.ToString("X8");
                Data44.Text = tdata44.ToString("X8");

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = tdata41.ToString("X8");
                Data62.Text = tdata42.ToString("X8");
                Data63.Text = tdata43.ToString("X8");
                Data64.Text = tdata44.ToString("X8");
            }
            else
            {
                Data41.Text = "00000000";
                Data42.Text = "00000000";
                Data43.Text = "00000000";
                Data44.Text = "00000000";

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = "00000000";
                Data62.Text = "00000000";
                Data63.Text = "00000000";
                Data64.Text = "00000000";
            }
        }

        private void Read5Click(object sender, RoutedEventArgs e)
        {
            Int32 WeaponAddress = 0x2F4495E0;
            int PageNum = 0x640;
            int RowNum = 0xA0;
            int ColNum = 0x10;

            var SelPage = (Convert.ToInt32(WPage51.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(WRow51.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(WCol51.SelectedItem)) - 1;

            //Now set the write field to be the same
            WPage61.SelectedItem = WPage51.SelectedItem;
            WRow61.SelectedItem = WRow51.SelectedItem;
            WCol61.SelectedItem = WCol51.SelectedItem;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

            Address51.Text = WeaponPointer.ToString("X8");

            //set the write address to be the same
            Address61.Text = WeaponPointer.ToString("X8");

            var weapondata = gecko.ReadBytes(WeaponPointer, 0x10);

            if (weapondata.Length > 0 && weapondata != null)
            {
                var tdata51 = BitConverter.ToInt32(weapondata.Skip(0).Take(4).Reverse().ToArray(), 0);
                var tdata52 = BitConverter.ToInt32(weapondata.Skip(4).Take(4).Reverse().ToArray(), 0);
                var tdata53 = BitConverter.ToInt32(weapondata.Skip(8).Take(4).Reverse().ToArray(), 0);
                var tdata54 = BitConverter.ToInt32(weapondata.Skip(12).Take(4).Reverse().ToArray(), 0);

                Data51.Text = tdata51.ToString("X8");
                Data52.Text = tdata52.ToString("X8");
                Data53.Text = tdata53.ToString("X8");
                Data54.Text = tdata54.ToString("X8");

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = tdata51.ToString("X8");
                Data62.Text = tdata52.ToString("X8");
                Data63.Text = tdata53.ToString("X8");
                Data64.Text = tdata54.ToString("X8");
            }
            else
            {
                Data51.Text = "00000000";
                Data52.Text = "00000000";
                Data53.Text = "00000000";
                Data54.Text = "00000000";

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = "00000000";
                Data62.Text = "00000000";
                Data63.Text = "00000000";
                Data64.Text = "00000000";
            }
        }

        private void WeaponWriteClick(object sender, RoutedEventArgs e)
        {
            Int32 WeaponAddress = 0x2F4495E0;
            int PageNum = 0x640;
            int RowNum = 0xA0;
            int ColNum = 0x10;

            var SelPage = (Convert.ToInt32(WPage61.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(WRow61.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(WCol61.SelectedItem)) - 1;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

            Address61.Text = WeaponPointer.ToString("X8");

            gecko.WriteBytes(WeaponPointer, gecko.StringToByteArray(Data61.Text));
            gecko.WriteBytes(WeaponPointer + 0x4, gecko.StringToByteArray(Data62.Text));
            gecko.WriteBytes(WeaponPointer + 0x8, gecko.StringToByteArray(Data63.Text));
            gecko.WriteBytes(WeaponPointer + 0xC, gecko.StringToByteArray(Data64.Text));

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Win1.Show();
        }
    }
}
